@echo off
setlocal
cd /d "%~dp0"
if not exist "gradlew.bat" (
  echo Le wrapper Gradle n'est pas fourni dans cette archive.
  echo Utilisez Android Studio ou GitHub Actions selon BUILD_APK.md.
  pause
  exit /b 1
)
call gradlew.bat :app:assembleDebug
if errorlevel 1 exit /b 1
echo APK cree dans app\build\outputs\apk\debug\app-debug.apk
pause
