# Obtenir le vrai APK installable de Poule tri One V2

Le projet contient maintenant un workflow GitHub Actions qui compile automatiquement un vrai APK Android Debug installable.

## Méthode recommandée — sans installer Android Studio

1. Créer un compte GitHub sur https://github.com/ si nécessaire.
2. Créer un nouveau dépôt, par exemple `PouleTriOne`.
3. Décompresser ce projet puis envoyer **tous les fichiers et dossiers** du projet dans le dépôt.
4. Vérifier que le fichier `.github/workflows/android.yml` est bien présent.
5. Ouvrir l'onglet **Actions** du dépôt GitHub.
6. Sélectionner **Construire l'APK Poule tri One**.
7. Cliquer sur **Run workflow**.
8. Attendre la fin avec une coche verte.
9. Ouvrir l'exécution terminée et télécharger l'artefact **Poule-tri-One-V2-APK**.
10. Dans l'archive téléchargée, récupérer `app-debug.apk`.
11. Transférer `app-debug.apk` sur le téléphone Android et l'installer.

## Important

- `PouleTriOne_V2_AndroidStudio.zip` est un **projet source**, pas un APK.
- Ne pas renommer le `.zip` en `.apk` : cela ne fonctionne pas.
- L'APK Debug est signé automatiquement pour permettre l'installation et les tests.
- Pour une publication Google Play, il faudra ensuite créer une vraie signature Release/keystore et préparer la fiche Play Store.
- L'application ne contient pas de publicité intrusive.

## Si l'installation Android bloque

Android peut demander l'autorisation d'installer des applications provenant de cette source. Autoriser temporairement l'installation pour l'application utilisée pour ouvrir le fichier (gestionnaire de fichiers ou navigateur), puis lancer l'installation.
