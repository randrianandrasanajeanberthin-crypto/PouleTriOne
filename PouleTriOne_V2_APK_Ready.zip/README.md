# Poule tri One V2 — Android

Auteur : RANDRIANANDRASANA JEAN BERTHIN
Version : 2.0

## Inclus dans ce prototype
- identité visuelle premium et logo
- tableau de bord
- gestion de lots
- formulation automatique de provende avec matières premières sélectionnables
- résultat en % totalisant 100 % et conversion en kg par lot
- estimation de coût en Ariary
- profils : poulet de chair, poule pondeuse, poulet local
- calendrier J1 → fin de cycle
- rappels/notifications : canal Android préparé
- assistant IA hors ligne : architecture UI prête pour un modèle local
- réseau/communauté : écran et architecture offline-first préparés
- mode hors ligne
- trois langues : Malagasy, Français, English (base d'interface préparée)
- aucune publicité intrusive

## Important
Les valeurs nutritionnelles incluses dans le prototype sont des données de démonstration.
Elles ne doivent pas être considérées comme une formulation professionnelle définitive.
Avant usage commercial ou zootechnique, remplacer/valider les profils et compositions
avec des références techniques locales et, si nécessaire, un vétérinaire/nutritionniste.

## Ouvrir
Ouvrir le dossier dans Android Studio, laisser Gradle synchroniser, puis lancer sur un téléphone Android
ou un émulateur. Compile SDK 35, min SDK 26.

## APK
Cet environnement de génération ne dispose pas du SDK Android/Gradle nécessaire pour compiler et signer
un APK directement. Le projet est donc fourni prêt à être ouvert dans Android Studio et compilé en APK.
