package com.pouletrione.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val DeepGreen = Color(0xFF063B28)
private val Gold = Color(0xFFD9AE45)
private val SoftGreen = Color(0xFFEAF4EE)

enum class Lang { FR, MG, EN }

data class Flock(val name: String, val type: String, val count: Int, val day: Int)
data class Ingredient(
    val name: String,
    val protein: Double,
    val energy: Double,
    val calcium: Double,
    val phosphorus: Double,
    val priceAr: Double,
    val min: Double = 0.0,
    val max: Double = 70.0
)

data class Profile(val label: String, val protein: Double, val energy: Double, val calcium: Double, val phosphorus: Double, val dailyG: Double)

class AppVM : ViewModel() {
    var lang by mutableStateOf(Lang.FR)
    var selectedType by mutableStateOf("Poulet de chair")
    var selectedStage by mutableStateOf("Croissance")
    var batchKg by mutableStateOf(100.0)
    var formulation by mutableStateOf<Map<String, Double>>(emptyMap())
    var totalCost by mutableStateOf(0.0)

    val flocks = listOf(
        Flock("Lot CH-001", "Poulet de chair", 500, 23),
        Flock("Lot PON-001", "Poule pondeuse", 350, 45),
        Flock("Lot LOC-001", "Poulet local", 80, 20)
    )

    val ingredients = listOf(
        Ingredient("Maïs", 8.5, 3350.0, 0.03, 0.25, 900.0, max=65.0),
        Ingredient("Son de riz", 13.0, 2500.0, 0.07, 1.55, 650.0, max=30.0),
        Ingredient("Tourteau de soja", 44.0, 2450.0, 0.30, 0.62, 2400.0, max=30.0),
        Ingredient("Farine de poisson", 60.0, 2800.0, 5.0, 3.0, 3200.0, max=8.0),
        Ingredient("Manioc", 3.0, 3000.0, 0.20, 0.15, 500.0, max=25.0),
        Ingredient("Huile", 0.0, 8800.0, 0.0, 0.0, 3000.0, max=5.0),
        Ingredient("CMV / Prémix", 0.0, 0.0, 18.0, 5.0, 5000.0, min=0.5, max=3.0)
    )

    fun profile(): Profile = when (selectedType) {
        "Poule pondeuse" -> Profile("Pondeuse", 17.5, 2700.0, 3.8, 0.45, 115.0)
        "Poulet local" -> Profile("Local", 18.0, 2850.0, 1.0, 0.45, 90.0)
        else -> when (selectedStage) {
            "Démarrage" -> Profile("Chair démarrage", 21.0, 3000.0, 1.0, 0.50, 45.0)
            "Finition" -> Profile("Chair finition", 19.0, 3150.0, 0.90, 0.45, 110.0)
            else -> Profile("Chair croissance", 20.0, 3050.0, 0.95, 0.48, 75.0)
        }
    }

    // Offline prototype optimizer: minimizes a weighted error on protein/energy/mineral targets + cost.
    // Values are editable/illustrative and must be validated against the user's local nutrition references.
    fun formulate(selected: Set<String>) {
        val pool = ingredients.filter { selected.contains(it.name) }
        if (pool.isEmpty()) return
        val p = profile()
        val n = pool.size
        var w = DoubleArray(n) { 100.0 / n }
        for (i in pool.indices) {
            w[i] = min(max(w[i], pool[i].min), pool[i].max)
        }
        normalize(w, pool)
        fun score(x: DoubleArray): Double {
            var pr = 0.0; var en = 0.0; var ca = 0.0; var ph = 0.0; var cost = 0.0
            for (i in x.indices) {
                val f = x[i] / 100.0
                pr += pool[i].protein * f
                en += pool[i].energy * f
                ca += pool[i].calcium * f
                ph += pool[i].phosphorus * f
                cost += pool[i].priceAr * f
            }
            return abs(pr-p.protein)*8 + abs(en-p.energy)/120 + abs(ca-p.calcium)*2 + abs(ph-p.phosphorus)*2 + cost/5000.0
        }
        var best = score(w)
        repeat(12000) {
            val a = (it * 17) % n
            val b = (it * 31 + 1) % n
            if (a != b && w[a] > pool[a].min + 0.2 && w[b] < pool[b].max - 0.2) {
                w[a] -= 0.2; w[b] += 0.2
                val s = score(w)
                if (s < best) best = s else { w[a] += 0.2; w[b] -= 0.2 }
            }
        }
        formulation = pool.indices.associate { pool[it].name to w[it] }
        totalCost = pool.indices.sumOf { pool[it].priceAr * w[it] / 100.0 } * batchKg
    }

    private fun normalize(w: DoubleArray, pool: List<Ingredient>) {
        var delta = 100.0 - w.sum()
        var guard = 0
        while (abs(delta) > 0.001 && guard++ < 1000) {
            val i = guard % w.size
            val room = if (delta > 0) pool[i].max - w[i] else w[i] - pool[i].min
            val move = min(abs(delta), max(0.0, room))
            w[i] += if (delta > 0) move else -move
            delta = 100.0 - w.sum()
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { PoultriOneApp() }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("poultry_reminders", "Rappels d'élevage", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }
}

@Composable
fun PoultriOneApp(vm: AppVM = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    var showAbout by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DeepGreen, secondary = Gold, background = Color(0xFFF8FAF8), surface = Color.White
        )
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    val labels = listOf("Accueil", "Lots", "Calendrier", "Réseau", "Plus")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Pets, Icons.Default.DateRange, Icons.Default.Groups, Icons.Default.MoreHoriz)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label) })
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> HomeScreen(vm, pad) { tab = 1 }
                1 -> LotsScreen(vm, pad)
                2 -> CalendarScreen(vm, pad)
                3 -> NetworkScreen(vm, pad)
                else -> MoreScreen(vm, pad) { showAbout = true }
            }
        }
        if (showAbout) AboutDialog(vm) { showAbout = false }
    }
}

@Composable
fun CoverHeader() {
    Column(
        Modifier.fillMaxWidth().background(DeepGreen).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(com.pouletrione.app.R.drawable.poule_tri_one_logo), null, Modifier.size(86.dp).clip(RoundedCornerShape(22.dp)), ContentScale.Crop)
        Spacer(Modifier.height(8.dp))
        Text("Poule tri One", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
        Text("L’intelligence au service de votre élevage", color = Gold, fontSize = 14.sp)
        Text("Version 2.0 • Hors ligne • Sans publicité intrusive", color = Color.White.copy(alpha=.8f), fontSize = 11.sp)
    }
}

@Composable
fun HomeScreen(vm: AppVM, pad: PaddingValues, goLots: () -> Unit) {
    LazyColumn(Modifier.padding(pad).fillMaxSize()) {
        item { CoverHeader() }
        item {
            Column(Modifier.padding(16.dp)) {
                Text("Bonjour, éleveur 👋", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Tout votre élevage, au même endroit.", color = Color.Gray)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Lots actifs", vm.flocks.size.toString(), Icons.Default.Pets, Modifier.weight(1f))
                    StatCard("Oiseaux", vm.flocks.sumOf { it.count }.toString(), Icons.Default.Groups, Modifier.weight(1f))
                }
                Spacer(Modifier.height(14.dp))
                Text("Fonctions principales", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                FeatureButton("🌾", "Nutrition & formulation", "Calcul automatique jusqu’à 100 %") { }
                FeatureButton("🧠", "Poultry IA", "Assistant local hors connexion") { }
                FeatureButton("🔔", "Notifications", "Rappels locaux, sans publicité") { }
                FeatureButton("📅", "Calendrier des cycles", "J1 → fin du cycle") { }
                FeatureButton("📡", "Réseau", "Échanger avec d’autres éleveurs") { }
                Spacer(Modifier.height(8.dp))
                Button(onClick = goLots, modifier = Modifier.fillMaxWidth()) { Text("Gérer mes lots") }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, null, tint = Gold)
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
fun FeatureButton(emoji: String, title: String, sub: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onClick() }) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 25.sp)
            Spacer(Modifier.width(12.dp))
            Column { Text(title, fontWeight = FontWeight.SemiBold); Text(sub, color = Color.Gray, fontSize = 12.sp) }
        }
    }
}

@Composable
fun LotsScreen(vm: AppVM, pad: PaddingValues) {
    var selected by remember { mutableStateOf<Flock?>(null) }
    var showNutrition by remember { mutableStateOf(false) }
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
        item {
            Text("Mes lots", fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Suivi local de vos élevages", color = Color.Gray)
            Spacer(Modifier.height(12.dp))
        }
        items(vm.flocks) { flock ->
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selected = flock }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🐔", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(flock.name, fontWeight = FontWeight.Bold)
                        Text("${flock.type} • J${flock.day} • ${flock.count} sujets", color = Color.Gray)
                    }
                    Icon(Icons.Default.ChevronRight, null)
                }
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            Button(onClick = { showNutrition = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Calculate, null); Spacer(Modifier.width(8.dp)); Text("Formuler une provende")
            }
        }
    }
    selected?.let { f ->
        AlertDialog(onDismissRequest = { selected = null }, confirmButton = { TextButton({ selected = null }) { Text("Fermer") } },
            title = { Text(f.name) }, text = { Text("${f.type}\nÂge : J${f.day}\nEffectif : ${f.count}\n\nLe suivi détaillé sera enrichi dans les prochaines itérations.") })
    }
    if (showNutrition) NutritionDialog(vm) { showNutrition = false }
}

@Composable
fun NutritionDialog(vm: AppVM, close: () -> Unit) {
    var selected by remember { mutableStateOf(vm.ingredients.map { it.name }.toSet()) }
    AlertDialog(onDismissRequest = close, confirmButton = {
        Button(onClick = { vm.formulate(selected) }) { Text("Calculer") }
    }, dismissButton = { TextButton(close) { Text("Fermer") } },
        title = { Text("🌾 Formulation automatique") },
        text = {
            Column {
                Text("Profil : ${vm.selectedType} • ${vm.selectedStage}", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Matières premières disponibles localement", color = Color.Gray)
                vm.ingredients.forEach { ing ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = selected.contains(ing.name), onCheckedChange = {
                            selected = if (it) selected + ing.name else selected - ing.name
                        })
                        Text(ing.name)
                    }
                }
                if (vm.formulation.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp)
                    )
                    Text("Résultat", fontWeight = FontWeight.Bold)
                    vm.formulation.forEach { (name, pct) ->
                        Text("$name  •  ${"%.2f".format(pct)} %  •  ${"%.2f".format(vm.batchKg * pct / 100)} kg")
                    }
                    Text("TOTAL : ${"%.2f".format(vm.formulation.values.sum())} %", fontWeight = FontWeight.Bold)
                    Text("Coût estimatif : ${"%.0f".format(vm.totalCost)} Ar", color = DeepGreen, fontWeight = FontWeight.Bold)
                    Text("Données nutritionnelles de démonstration : à valider avec une référence technique locale.", fontSize = 10.sp, color = Color.Gray)
                }
            }
        })
}

@Composable
fun CalendarScreen(vm: AppVM, pad: PaddingValues) {
    var type by remember { mutableStateOf("Poulet de chair") }
    val maxDay = if (type == "Poule pondeuse") 140 else 35
    val events = remember(type) {
        if (type == "Poulet de chair") listOf(
            1 to "Arrivée • installation, température, eau",
            3 to "Contrôle initial • observation",
            7 to "Pesée • suivi de croissance",
            14 to "Pesée + contrôle sanitaire",
            21 to "Pesée • ajustement alimentation",
            28 to "Contrôle sanitaire + préparation",
            35 to "Fin de cycle • bilan / vente"
        ) else listOf(
            1 to "Installation et contrôle initial",
            7 to "Pesée et observation",
            28 to "Bilan de croissance",
            56 to "Bilan sanitaire",
            90 to "Suivi de production",
            120 to "Évaluation du lot",
            140 to "Jalon configurable"
        )
    }
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
        item {
            Text("Calendrier du cycle", fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("J1 → J$maxDay • événements personnalisables", color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Poulet de chair", "Poule pondeuse").forEach { t ->
                    FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        items(events) { (day, event) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(50), color = SoftGreen) {
                        Text("J$day", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), fontWeight = FontWeight.Bold, color = DeepGreen)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(event)
                }
            }
        }
    }
}

@Composable
fun NetworkScreen(vm: AppVM, pad: PaddingValues) {
    LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
        item {
            Text("Réseau / Communauté", fontSize = 27.sp, fontWeight = FontWeight.Bold)
            Text("Communication entre utilisateurs de Poule tri One", color = Color.Gray)
            Spacer(Modifier.height(14.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("📡 Mode hors ligne", fontWeight = FontWeight.Bold)
                    Text("Les données restent sur le téléphone. La synchronisation est différée jusqu’au retour d’Internet.")
                    Spacer(Modifier.height(10.dp))
                    Text("🟢 Prêt pour la synchronisation", color = DeepGreen, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(10.dp))
            FeatureButton("💬", "Messages", "Préparer des conversations entre éleveurs") {}
            FeatureButton("👥", "Groupes", "Communautés par région ou type d’élevage") {}
            FeatureButton("📤", "Partager une formulation", "Envoyer un résultat à un autre utilisateur") {}
            FeatureButton("🔄", "Synchroniser", "Transférer les éléments en attente") {}
        }
    }
}

@Composable
fun MoreScreen(vm: AppVM, pad: PaddingValues, about: () -> Unit) {
    Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
        Text("Plus", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        FeatureButton("🌍", "Langue", "Malagasy • Français • English") {}
        FeatureButton("🔔", "Notifications", "Rappels locaux") {}
        FeatureButton("📚", "Sources & références", "Documents utilisés par l’assistant") { about() }
        FeatureButton("ℹ️", "À propos", "Poule tri One V2.0") { about() }
        Spacer(Modifier.height(12.dp))
        Text("Aucune publicité intrusive. Les notifications sont réservées aux rappels de l’élevage.", color = DeepGreen, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AboutDialog(vm: AppVM, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close,
        confirmButton = { TextButton(close) { Text("Fermer") } },
        title = { Text("Poule tri One") },
        text = {
            Column {
                Image(painterResource(R.drawable.poule_tri_one_logo), null, Modifier.size(80.dp).align(Alignment.CenterHorizontally))
                Spacer(Modifier.height(8.dp))
                Text("Version 2.0", fontWeight = FontWeight.Bold)
                Text("Application intelligente de gestion et de suivi de l’élevage avicole.")
                Spacer(Modifier.height(8.dp))
                Text("Auteur : RANDRIANANDRASANA JEAN BERTHIN")
                Text("Langues : Malagasy • Français • English")
                Text("Fonctionnement hors ligne-first")
                Text("Aucune publicité intrusive")
                Spacer(Modifier.height(8.dp))
                Text("Sources & références : les données nutritionnelles et recommandations doivent être reliées à des références techniques validées et actualisées avant usage professionnel.", fontSize = 11.sp, color = Color.Gray)
            }
        }
    )
}
